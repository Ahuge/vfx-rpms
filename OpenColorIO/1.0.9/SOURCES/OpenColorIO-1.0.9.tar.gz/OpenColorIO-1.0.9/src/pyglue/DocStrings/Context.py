
class Context:
    """
    Context
    """
    def __init__(self):
        pass
    def isEditable(self):
        pass
    def createEditableCopy(self):
        pass
    def getCacheID(self):
        pass
    def getSearchPath(self):
        pass
    def setSearchPath(self, searchPath):
        pass
    def getWorkingDir(self):
        pass
    def setWorkingDir(self, workingDir):
        pass
    def getStringVar(self):
        pass
    def setStringVar(self, stringVar):
        pass
    def getNumStringVars(self):
        pass
    def getStringVarNameByIndex(self, index):
        pass
    def clearStringVars():
        pass
    def setEnvironmentMode(self, mode):
        pass
    def getEnvironmentMode():
        pass
    def loadEnvironment(self):
        pass
    def resolveStringVar(self, stringVar):
        pass
    def resolveFileLocation(self, fileLocation):
        pass

