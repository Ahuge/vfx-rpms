
class FileTransform:
    """
    FileTransform
    """
    def __init__(self):
        pass
    def getSrc(self):
        pass
    def setSrc(self, src):
        pass
    def getCCCId(self):
        pass
    def setCCCId(self, cccid):
        pass
    def getInterpolation(self):
        pass
    def setInterpolation(self, interp):
        pass
    def getNumFormats(self):
        pass
    def getFormatNameByIndex(self, index):
        pass
    def getFormatExtensionByIndex(self, index):
        pass
