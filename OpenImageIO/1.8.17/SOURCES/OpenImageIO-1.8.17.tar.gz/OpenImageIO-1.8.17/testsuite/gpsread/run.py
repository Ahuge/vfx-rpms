#!/usr/bin/env python

command = info_command (parent + "/oiio-images/tahoe-gps.jpg")
