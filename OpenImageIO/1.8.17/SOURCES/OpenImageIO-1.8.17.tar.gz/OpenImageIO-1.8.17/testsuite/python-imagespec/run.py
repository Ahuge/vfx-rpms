#!/usr/bin/env python 

command += "python src/test_imagespec.py > out.txt"

