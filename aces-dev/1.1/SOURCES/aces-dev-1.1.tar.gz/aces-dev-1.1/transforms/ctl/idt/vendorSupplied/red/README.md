

RED supplied Input Device Transforms (IDTs) can be applied to R3D files by using the "Use ACES" export option in REDCINE-X PRO:

REDCINE-X PRO is can be downloaded from:
https://www.red.com/downloads?category=Software&release=final

