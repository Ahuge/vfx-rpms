#!/usr/bin/env python

command = rw_command (OIIO_TESTSUITE_IMAGEDIR, "oiio.ico")
