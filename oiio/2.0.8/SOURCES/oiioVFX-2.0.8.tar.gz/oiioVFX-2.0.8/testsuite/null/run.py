#!/usr/bin/env python

command += oiiotool ("-v -info -stats 'foo.null?RES=640x480&CHANNELS=3&TYPE=uint8&PIXEL=0.25,0.5,1'")
